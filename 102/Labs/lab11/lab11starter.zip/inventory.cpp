#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include "inventory.h"

using namespace std;

Inventory::Inventory(string filename)
{
	// ************* TO DO *************
	
	// read in the inventory from the file specified by filename
	// the file should contain three pieces of data per item,
	// formatted as follows:
	// [name] [dollars] [cents]
	// add each item to the items vector
}

void Inventory::addItem(Item *item)
{
	// ************* TO DO *************
	// add the item to the items vector
}

Item *Inventory::getItem(int index)
{
	// ************* TO DO *************
	// return the item specified by index
	return NULL;
}

int Inventory::getNumItems()
{
	// ************* TO DO *************
	// return the number of items in the inventory
	return 0;
}

string Inventory::toString()
{
	stringstream ss;
	for (int i = 0; i < items.size(); ++i)
	{
		ss << i << ":" << setw(10) << items[i]->getName() << setw(8) << items[i]->getPrice().toString() << endl;
	}
	return ss.str();
}
